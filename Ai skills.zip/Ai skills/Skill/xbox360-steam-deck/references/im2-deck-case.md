# Iron Man 2 Steam Deck case and implementation map

Case snapshot: 2026-11-20. The user confirmed native launch after manual
execute-bit repair. A screenshot shows the ReXGlue Debug window rendering
the SEGA startup logo in Desktop Mode. Detailed gameplay graphics, audio,
controls, save/reload and sustained FPS were not separately demonstrated.

This reference remains useful outside the original project. Paths below name
the IM2 implementation for inspection when available; do not assume those
helpers exist in another game's repository or install this game with the skill.

## Working bundle arrangement

```text
SteamDeck-IronMan2/
  Launch.sh
  Check.sh
  lib/common.sh
  config/deck-settings.conf
  bin/ironman2
  bin/ld-linux-x86-64.so.2
  bin/<SDK modules and copied modern SDL3>
  fixes/<audio, storage, window and stencil adapters>
  fixes/VkLayer_im2_stencil.json
  runtime/lib/<matching private glibc and C++ libraries>
  licenses/
  game/<user's 77-file extraction>
  BUILD-INFO.json
  VALIDATION.json
```

The private bundle is about 6.3 GiB and ignored by git. A copy contains game
data and captured shader code; it was prepared for local use, not publication.
No private saves were copied into it.

## Library and path decisions

- The executable requires `sqrtf@GLIBC_2.43`; SDK Vulkan code requires GLIBC_2.38
  and GLIBCXX_3.4.32. The copied modern SDL also needs newer glibc. Inspect all
  actual files rather than checking only the game ELF.
- A matching private glibc 2.43 loader, libc/libm, compatibility DSOs, libstdc++
  and libgcc accompany the unchanged game/SDK. This is a pinned local solution,
  not a universal Steam Deck prerequisite or a patch to the SDK's ABI guard.
- The loader resides beside the executable/modules because direct execution
  changes `/proc/self/exe`. The launcher sets `app.root` and its working
  directory to `bin/`, and supplies the game/user-data roots explicitly.
- `--library-path` and preload basenames isolate private libraries to the game
  and support bundle paths with spaces. The normal desktop shell is unchanged.
- The stencil manifest uses `./libVkLayer_im2_stencil.so`. The modern SDL is a
  copied file named for the SDK dependency, not a symlink into the source PC.
- Vulkan/Mesa and host audio/display backends remain destination-OS libraries.
  No PC-specific NVIDIA driver is included.

## Profile and working fixes

| Item | IM2 setting / scope |
| --- | --- |
| Window | Request 1280x720 with a scoped SDL adapter; 1152x648 optional for desktop room; actual size is not measured by the screenshot |
| Smoothing | FXAA, 8x anisotropic (`IM2_DECK_AF=4`), letterboxing and 1x internal scale |
| Performance | 30 FPS cap is a target, not a benchmark; VSync enabled |
| Vulkan | FBO; FSI asserted on first draw in this SDK |
| Audio | Before-mixer pacing at 187.5 Hz, SDK queue 8, initial gain 0.10; desktop audible fix user-confirmed |
| Storage | Fake-HDD content root plus targeted async-completion adapter; save/relaunch/load still unverified |
| Lighting | Exact-match stencil transfer correction; desktop opening-scene fix user-confirmed; Deck splash screenshot does not verify the affected gameplay |

The launcher sources `config/deck-settings.conf` after inherited environment
values. Its profile assignments therefore win over those names in the parent
shell. The packager preserves an existing profile while replacing source
launcher/check/common/README copies. Existing audio/storage/stencil adapters
are copied; only the window adapter is rebuilt automatically by the packager.

## Transfer failure and recovery

The original shared check used `-x` and reported "private Linux loader missing
or drive mounted noexec" for several distinct causes. A Deck terminal screenshot
showed both binaries present with `-rw-r--r--`. File sizes were 91,803,312 bytes
for the game and 1,002,600 for the loader. The user ran, from the Deck copy:

```bash
chmod u+x bin/ld-linux-x86-64.so.2 bin/ironman2 Launch.sh Check.sh
bash Check.sh
bash Launch.sh
```

The dependency check passed, then the user reported "it works" and showed the
startup logo. This establishes manual recovery and native startup. It does
not establish a `noexec` mount as the cause; mount options were not supplied.

The current PC launcher additionally repairs missing owner execute bits,
checks mount options before chmod, distinguishes absent/unreadable files and
preserves loader-probe failures. `Launch.sh --check` uses Bash for `Check.sh`.
Controlled host tests passed this automatic repair path; the Deck confirmation
was for the preceding manual repair, not automatic repair on the device.

## Original implementation and evidence locations

| Repository path | Purpose |
| --- | --- |
| `ironman2/tools/deck/` | Source launcher, common/check script, default profile and README |
| `ironman2/tools/deck_window.c` | Scoped public SDL3 C interposition; handles global/local symbol scope and window lifetime |
| `ironman2/tools/build-steam-deck.sh` | Preflight and local assembly; preserves active profile and omits saves |
| `ironman2/tools/test-deck-window.sh` | Controlled size/minimum/fullscreen/helper/opt-out/lifetime checks |
| `ironman2/tools/test-deck-launcher.py` | Relocated path-with-spaces, real preload binding, arguments, manifest and invalid profile checks using a stand-in |
| `ironman2/tools/test-deck-permissions.py` | Lost execute bits, missing loader, simulated noexec and controlled probe failures |
| `ironman2/logs/steam-deck-content-check.json` | All 77 copied game files, 6,396,282,788 bytes, match extraction SHA-256 |
| `ironman2/logs/steam-deck-user-validation.json` | User launch/startup evidence, command history, reference build hashes and limits |
| `SteamDeck-IronMan2/BUILD-INFO.json` | Original assembly evidence; its untested-at-assembly flag is historical |
| `SteamDeck-IronMan2/VALIDATION.json` | Later user confirmation, kept separate from original assembly |

The known exit-only SDK abort and separately reported whole-PC crash were
not declared fixed by the successful Deck startup. Do not replay disruptive
GPU/audio captures merely to check documentation or packaging changes.
