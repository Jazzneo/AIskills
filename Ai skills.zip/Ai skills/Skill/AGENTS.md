# AGENTS.md — How to use these Xbox 360 porting skills

This folder contains two reusable skills. Read the target game's project
instructions first, then choose the skill that matches the current task.
This guide covers skill usage and maintenance; the project's root
`AGENTS.md` remains the source for its build rules and verified results.

## Choose a skill

| Label | Read this file | Use it for |
| --- | --- | --- |
| **Xbox 360 Native Linux Port** | [xbox360-native-linux/SKILL.md](xbox360-native-linux/SKILL.md) | Starting a native port; executable analysis, translation/codegen, runtime integration, Linux builds and audio/graphics/save/input fixes |
| **Xbox 360 Native Port for Steam Deck** | [xbox360-steam-deck/SKILL.md](xbox360-steam-deck/SKILL.md) | Adapting an existing Linux port; portable libraries, window sizing, image settings, controls, transfer permissions and on-device validation |

For a new game, establish the Linux baseline first, then use the Steam Deck
skill for the device-specific work. For an existing working port, start with
the relevant maintenance or packaging stage instead of repeating extraction
and translation.

## Use the files directly in this project

These skill folders are stored locally under `Skill/`; they have not been
installed globally. Ask the agent to read the exact file. This does not
require moving files or changing Codex settings.

Example request for a Linux port:

```text
Read Skill/AGENTS.md and Skill/xbox360-native-linux/SKILL.md.
Use that workflow to make a native Linux port from my supplied Xbox 360
game files. Identify the title/revision and toolchain, preserve existing
working fixes and saves, and record what actually builds and runs.
```

Example request for Steam Deck:

```text
Read Skill/AGENTS.md and Skill/xbox360-steam-deck/SKILL.md.
Use that workflow to adapt my existing native Linux port for Steam Deck.
Make a movable package with a suitable window and graphics profile, keep
its working audio/save/graphics fixes, and check transfer permissions.
Separate PC checks from results verified on the Deck.
```

Example request for a specific problem:

```text
Read Skill/xbox360-native-linux/SKILL.md and the relevant audio reference.
Investigate distorted sound in this port. Trace this game's actual render
callback and compare existing evidence before changing its timing.
```

Give the agent the target project, game-data location and observed problem
when those are not already known. A skill is a workflow, not a shell program;
do not run `SKILL.md` in a terminal.

## Read the matching reference when needed

- [Linux porting lessons](xbox360-native-linux/references/im2-lessons.md):
  translation/runtime distinctions, GCC 13 ABI, audio callback pacing,
  stencil correction, targeted save completion, SDL and shutdown findings.
- [Steam Deck case](xbox360-steam-deck/references/im2-deck-case.md):
  private runtime layout, portable paths, graphics profile, execute-bit
  recovery, test helpers and the user's confirmed startup.

These references document Iron Man 2. Recover another game's own callback
addresses, save callers, executable revision, shader identities and SDK ABI.
Do not copy IM2 constants or captured shaders as a general fix. A successful
startup is separate from verified gameplay, audio, controls, FPS and save/load.

## Reuse the skills in another project

Copy each chosen skill's **whole folder**, including `SKILL.md`, `agents/`
and `references/`. Then ask the agent to read its new path as above. Do not
copy game assets, generated guest code, binaries, captures or personal saves
into a skill folder.

For automatic Codex discovery, the documented repository location is
`.agents/skills/`, and the user location is `~/.agents/skills/`. A folder named
`Skill/` alone is not one of those discovery locations. Install there only
when requested; this guide does not install or enable anything. See the
[official skill documentation](https://learn.chatgpt.com/docs/build-skills).

Once a skill is installed and visible in the active session, it can be
explicitly selected by name, for example:

```text
Use $xbox360-native-linux to bring up this title on Linux.
Use $xbox360-steam-deck to package this existing port for my Steam Deck.
```

If it is not visible, use the direct-file request instead of assuming the
`$` name loaded it. Keep the folder intact whichever usage method is chosen.

## Instructions for agents maintaining this folder

- Keep each skill's folder name and frontmatter `name` consistent. Preserve
  the required uppercase `SKILL.md` filename.
- Keep its display label and example invocation in `agents/openai.yaml`
  consistent with its entrypoint. Load only references relevant to the task.
- Put reusable decisions in the entrypoint and title-specific evidence in
  references. Preserve the distinction between measured, user-reported and
  unverified results.
- Follow the target project's permissions, ABI rules and save-preservation
  requirements. Reading a skill does not authorize unrelated installs,
  publication or system changes.
- For documentation-only edits, check links, metadata and examples; do not
  rebuild the game, recopy the extraction or run GPU/audio captures merely
  to validate wording.

This nested `AGENTS.md` applies to work in `Skill/`; it does not automatically
load both skills for every task at the project root. Root-to-directory
instruction loading is described in the
[official AGENTS.md documentation](https://learn.chatgpt.com/docs/agent-configuration/agents-md).
