# Iron Man 2: evidence and mechanisms to adapt

Case snapshot: 2026-11-20, title `53450836`, ReXGlue v0.11.0, Linux x86-64.
The original repository's `AGENTS.md`, `Skills.md` and `ironman2/` logs contain
the detailed evidence. This reference is self-contained when the skill folder
is copied elsewhere; the named repository paths below are provenance, not
required files in a new game's workspace.

## Toolchain and code generation

The earlier XenonRecomp investigation emitted 39,852 functions; its stock
analyzer found zero switch tables, while custom recovery found 305. ReXGlue's
codegen independently recovered 416 and emitted the source consumed by the
native `rex-im2` build. The two generated trees are not interchangeable build
inputs. Do not require both translators for every new title.

Prebuilt SDK C++ interfaces required GCC 13 headers. Clang's default newer
libstdc++ headers failed the guard. Homebrew GCC lacked the triple-directory
layout expected by `--gcc-install-dir`; verified explicit `-nostdinc++` and
three GCC 13 include directories satisfied the ABI honestly. The original
Homebrew paths are absent in the current agent environment, so a full cached
game build cannot currently run there. Small standalone adapters still build.

## Audio pacing: user-confirmed fix

Registration at `sub_82585698` supplied callback `0x825854B8`. Its wrapper
tail-calls `sub_825852F0`, which mixes/submits audio. Repeated non-silent blocks
at lag 1,024 were observed; guest and SDL captures otherwise aligned closely.
Pacing the actual callback before mixing corrected the user's distorted sound.

This SDK uses 256 samples/channel at 48 kHz: 187.5 callbacks/s and a period of
`16,000,000 / 3 ns`. Use per-client monotonic deadlines, immediate first call,
fractional nanoseconds and rebasing after a missed deadline. Normal wake jitter
retains phase; overshoot above 1,333,333 ns rebases. Keep queue credits and do
not run a burst to catch up.

The deployed x86-64 adapter wraps:

```text
_ZN3rex6kernel18FunctionDispatcher7ExecuteEPNS0_11ThreadStateEjPmm
```

It targets callback `0x825854B8` with one non-null argument; all other calls
forward normally. It resolves the already-loaded kernel in global/local scope.
These address/ABI guards belong only to this SDK/title. Controlled timing,
forwarding and real SDK binding checks preceded user gameplay confirmation.
The source pacing hook exists, but the current executable was not rebuilt
with it; launcher preload is the deployed path. Avoid activating two pacers.

Normal settings are queue 8 and gain 0.10. A 32-block queue was not the cadence
fix. The Downpour/upstream XMA reset correction was already present, so adding
it again was not the successful change. No blanket Linux XMA defect was shown.

Provenance: `rex-im2/src/audio_callback_pacing.{h,cpp}`,
`ironman2/tools/audio_callback_dispatch_shim.cpp`,
`ironman2/tools/test-audio-callback-pacing.sh`, and
`ironman2/CALLBACK-PACING.md`.

## Graphics, saves, controllers and exit

| Problem | Observed IM2 correction / limit |
| --- | --- |
| Red flashes in scene lighting | Exact-match Vulkan layer inserts missing source-stencil discard in defective transfer shaders; nine keys, four distinct binaries; opening-scene desktop fix user-confirmed |
| Render-path choice | FBO works; FSI causes first-draw assertions in this SDK; these are IM2 observations, not universal recommendations for all versions |
| Save failure after successful host I/O | Only a completed overlapped 128 KiB write at the traced callers reports pending while preserving the real completion result; full save/relaunch/load progression remains unverified |
| Save caller guards | Return LR `0x82430EC0`, saved caller `0x823A88E4`, nonzero event and full completion; recover different guards for another title |
| New Steam Controller puck absent | Bundled SDL was too old for USB `28de:1304`; the system SDL enumerated it. A copied newer library is required in a portable bundle, not a PC-only symlink |
| Exit-only abort | Shutdown clears the GPU worker flag, interrupts WAIT_REG_MEM and reaches an unconditional assertion; distinguish from a packet failure during play |

Provenance: `ironman2/RED-TINT-RESEARCH.md`, `ironman2/STORAGE.md`,
`ironman2/BUGREPORT-rexglue.md`, `ironman2/tools/stencil_fix_layer.cpp`,
`ironman2/tools/storage_write_shim.cpp` and their focused tests.

An additional whole-PC crash was reported after capture; the audio fix did
not prove that host problem repaired. Prefer surviving captures and offline
analysis instead of repeatedly reproducing a disruptive run.

## Primary documentation

- [XenonRecomp](https://github.com/hedge-dev/XenonRecomp): translation-only
  role, analyzer limitations, memory/vector ordering and hook mechanism.
- [ReXGlue getting started](https://docs.rexglue.com/getting-started/):
  project/codegen flow and compiler/SDK compatibility; check the pinned release.
- [ReXGlue settings](https://docs.rexglue.com/reference/cvars/): supported
  names and ranges; do not assume other versions register the same flags.
